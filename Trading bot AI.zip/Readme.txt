Avviate il bot
ci mettera un po a aprire la finestra, solo la prima volta poi si avvierà subito

